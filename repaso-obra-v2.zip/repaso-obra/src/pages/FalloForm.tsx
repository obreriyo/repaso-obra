import { useEffect, useRef, useState } from 'react'
import type { ChangeEvent, FormEvent } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import MarcarFoto from '../components/MarcarFoto'
import { Estado, Pantalla } from '../components/Pantalla'
import * as api from '../lib/api'
import { useCarga, usePlan, useUrlsFotos } from '../lib/hooks'
import { ESTANCIAS, ESTANCIAS_ZONA, PRIORIDAD_TEXTO, TIPOS, TRASTERO, ZONA, mensajeError } from '../lib/format'
import { esNativa } from '../lib/nativo'
import type { EstadoFallo, Foto, Prioridad } from '../lib/types'

interface FotoNueva {
  archivo: File
  vista: string
}

const PRIORIDADES: Prioridad[] = ['alta', 'media', 'baja']

/** Máximo de fotos por fallo (cuida el espacio y las descargas) */
const MAX_FOTOS = 10

export default function FalloForm() {
  const { obraId = '', viviendaId, falloId } = useParams()
  const nav = useNavigate()
  const edicion = Boolean(falloId)

  const fallo = useCarga(() => (falloId ? api.getFallo(falloId) : Promise.resolve(null)), [falloId])
  const viv = useCarga(() => (viviendaId ? api.getVivienda(viviendaId) : Promise.resolve(null)), [viviendaId])
  const subs = useCarga(() => api.listSubcontratas(obraId), [obraId])

  const [estancia, setEstancia] = useState('')
  const [tipo, setTipo] = useState('Acabado')
  const [descripcion, setDescripcion] = useState('')
  const [prioridad, setPrioridad] = useState<Prioridad>('media')
  const [subcontrata, setSubcontrata] = useState('')
  const [estado, setEstado] = useState<EstadoFallo>('abierto')
  const [nuevas, setNuevas] = useState<FotoNueva[]>([])
  const [quitadas, setQuitadas] = useState<Foto[]>([])
  const [error, setError] = useState<string | null>(null)
  const [guardando, setGuardando] = useState(false)
  const [marcando, setMarcando] = useState<{ src: string; nueva?: number; existente?: Foto } | null>(null)
  const iniciado = useRef(false)

  const datos = fallo.datos
  const vivId = viviendaId ?? datos?.vivienda_id ?? ''
  const volver = `/obra/${obraId}/vivienda/${vivId}`

  useEffect(() => {
    // Solo se rellena una vez: si los datos se recargan mientras se escribe, no se pisa lo escrito
    if (!datos || iniciado.current) return
    iniciado.current = true
    setEstancia(datos.estancia)
    setTipo(datos.tipo)
    setDescripcion(datos.descripcion)
    setPrioridad(datos.prioridad)
    setSubcontrata(datos.subcontrata ?? '')
    setEstado(datos.estado)
  }, [datos])

  // En un trastero nuevo, la estancia ya es «Trastero»
  useEffect(() => {
    if (!edicion && viv.datos?.planta === TRASTERO) setEstancia((e) => e || 'Trastero')
    if (!edicion && viv.datos?.planta === ZONA) setEstancia((e) => e || 'General')
  }, [edicion, viv.datos])

  const existentes = (datos?.fotos ?? []).filter((f) => !quitadas.some((q) => q.id === f.id))
  const urls = useUrlsFotos(existentes.map((f) => f.path))

  const plan = usePlan(obraId)
  const cupoFallo = Math.max(0, MAX_FOTOS - existentes.length - nuevas.length)
  // Versión gratuita: tope de fotos entre todas las de la obra
  const cupoPlan = plan.gratis && plan.estado?.fotos_obra != null
    ? Math.max(0, plan.estado.max_fotos - plan.estado.fotos_obra - nuevas.length)
    : Infinity
  const cupoFotos = Math.min(cupoFallo, cupoPlan)
  const textoCupo = cupoPlan < cupoFallo || cupoPlan === 0
    ? 'La versión gratuita permite 15 fotos en total. Pasa a la versión de pago para añadir más.'
    : `Máximo ${MAX_FOTOS} fotos por fallo.`

  function añadirFotos(e: ChangeEvent<HTMLInputElement>) {
    const archivos = Array.from(e.target.files ?? [])
    e.target.value = ''
    if (archivos.length === 0) return
    const admitidas = archivos.slice(0, cupoFotos)
    setError(admitidas.length < archivos.length ? textoCupo : null)
    if (admitidas.length === 0) return
    setNuevas((lista) => [...lista, ...admitidas.map((archivo) => ({ archivo, vista: URL.createObjectURL(archivo) }))])
  }

  /** En el APK: abre la cámara de Android de verdad (el selector de archivos solo ofrece la galería). */
  async function hacerFoto() {
    setError(null)
    if (cupoFotos === 0) return setError(textoCupo)
    try {
      const { Camera, CameraResultType, CameraSource } = await import('@capacitor/camera')
      const foto = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        correctOrientation: true,
        resultType: CameraResultType.Uri,
        source: CameraSource.Camera
      })
      if (!foto.webPath) return
      const respuesta = await fetch(foto.webPath)
      const blob = await respuesta.blob()
      const archivo = new File([blob], `foto_${Date.now()}.jpg`, { type: blob.type || 'image/jpeg' })
      setNuevas((lista) => [...lista, { archivo, vista: URL.createObjectURL(archivo) }])
    } catch (e) {
      // Cerrar la cámara sin hacer la foto no es un error
      const texto = e instanceof Error ? e.message : String(e)
      if (/cancel/i.test(texto)) return
      setError(`No se pudo abrir la cámara: ${texto}`)
    }
  }

  /** Guarda la foto ya marcada: sustituye a la nueva o, si ya estaba guardada, la reemplaza. */
  function fotoMarcada(archivo: File) {
    if (!marcando) return
    const vista = URL.createObjectURL(archivo)
    if (marcando.nueva !== undefined) {
      const i = marcando.nueva
      setNuevas((lista) => {
        if (lista[i]) URL.revokeObjectURL(lista[i].vista)
        return lista.map((n, k) => (k === i ? { archivo, vista } : n))
      })
    } else if (marcando.existente) {
      const vieja = marcando.existente
      setNuevas((lista) => [...lista, { archivo, vista }])
      setQuitadas((q) => [...q, vieja])
    }
    setMarcando(null)
  }

  function quitarNueva(i: number) {
    setNuevas((lista) => {
      URL.revokeObjectURL(lista[i].vista)
      return lista.filter((_, k) => k !== i)
    })
  }

  async function guardar(e: FormEvent) {
    e.preventDefault()
    setError(null)
    if (!estancia.trim()) return setError('Indica la estancia.')
    if (!descripcion.trim()) return setError('Describe el fallo.')
    if (!vivId) return setError('No se encuentra la vivienda.')

    setGuardando(true)
    try {
      const comunes = {
        estancia: estancia.trim(),
        tipo,
        descripcion: descripcion.trim(),
        prioridad,
        subcontrata: subcontrata.trim() || null
      }

      let id = falloId
      if (id) {
        await api.actualizarFallo(id, { ...comunes, estado })
      } else {
        id = await api.crearFallo({ obra_id: obraId, vivienda_id: vivId, ...comunes })
        await api.marcarEnCurso(vivId)
      }

      if (comunes.subcontrata) await api.crearSubcontrata(obraId, comunes.subcontrata)
      for (const foto of quitadas) await api.borrarFoto(foto)
      for (const nueva of nuevas) await api.subirFoto(obraId, id, nueva.archivo)

      nav(volver, { replace: true })
    } catch (err) {
      setError(mensajeError(err))
      setGuardando(false)
    }
  }

  async function eliminar() {
    if (!falloId) return
    if (!window.confirm('¿Eliminar este fallo y sus fotos? No se puede deshacer.')) return
    setGuardando(true)
    try {
      await api.borrarFallo(falloId)
      nav(volver, { replace: true })
    } catch (err) {
      setError(mensajeError(err))
      setGuardando(false)
    }
  }

  return (
    <Pantalla titulo={edicion ? 'Editar fallo' : 'Nuevo fallo'} atras={{ a: volver, texto: 'Vivienda' }}>
      <Estado cargando={edicion && fallo.cargando} error={fallo.error} />

      <form onSubmit={guardar} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="campo">
          <span className="etiqueta">Fotos</span>
          <div className="fotos">
            {existentes.map((f) => (
              <div key={f.id} className="foto" style={urls[f.path] ? { backgroundImage: `url(${urls[f.path]})` } : undefined}>
                <button type="button" aria-label="Quitar foto" onClick={() => setQuitadas((q) => [...q, f])}>
                  ×
                </button>
                {urls[f.path] && (
                  <button type="button" className="marcar-btn" onClick={() => setMarcando({ src: urls[f.path], existente: f })}>
                    Marcar
                  </button>
                )}
              </div>
            ))}
            {nuevas.map((n, i) => (
              <div key={n.vista} className="foto" style={{ backgroundImage: `url(${n.vista})` }}>
                <button type="button" aria-label="Quitar foto" onClick={() => quitarNueva(i)}>
                  ×
                </button>
                <button type="button" className="marcar-btn" onClick={() => setMarcando({ src: n.vista, nueva: i })}>
                  Marcar
                </button>
              </div>
            ))}
            {esNativa() ? (
              <button type="button" className="foto-nueva" onClick={() => void hacerFoto()}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B1F24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M4 8h3l2-3h6l2 3h3v11H4z" />
                <circle cx="12" cy="13" r="3.5" />
              </svg>
                Cámara
              </button>
            ) : (
              <label className="foto-nueva">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B1F24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M4 8h3l2-3h6l2 3h3v11H4z" />
                  <circle cx="12" cy="13" r="3.5" />
                </svg>
                Cámara
                <input type="file" accept="image/*" capture="environment" onChange={añadirFotos} />
              </label>
            )}
            <label className="foto-nueva">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B1F24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect x="3" y="4" width="18" height="16" rx="2" />
                <circle cx="9" cy="10" r="1.8" />
                <path d="M21 16l-5-5-8 9" />
              </svg>
              Galería
              <input type="file" accept="image/*" multiple onChange={añadirFotos} />
            </label>
          </div>
          <span className="muted">Haz una foto con la cámara o elige varias de la galería (máximo 10 por fallo). Toca «Marcar» en una foto para dibujar círculos o flechas sobre ella.</span>
        </div>

        <div className="campo">
          <label htmlFor="estancia">Estancia</label>
          <div className="chips">
            {(viv.datos?.planta === ZONA ? ESTANCIAS_ZONA : ESTANCIAS).map((e) => (
              <button key={e} type="button" className={`chip ${estancia === e ? 'act' : ''}`} onClick={() => setEstancia(e)}>
                {e}
              </button>
            ))}
          </div>
          <input id="estancia" type="text" list="lista-estancias" value={estancia} onChange={(e) => setEstancia(e.target.value)} placeholder="O escribe otra estancia" />
          <datalist id="lista-estancias">
            {(viv.datos?.planta === ZONA ? ESTANCIAS_ZONA : ESTANCIAS).map((e) => (
              <option key={e} value={e} />
            ))}
          </datalist>
        </div>

        <div className="campo">
          <span className="etiqueta">Tipo de fallo</span>
          <div className="chips">
            {TIPOS.map((t) => (
              <button key={t} type="button" className={`chip ${tipo === t ? 'act' : ''}`} onClick={() => setTipo(t)}>
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="campo">
          <label htmlFor="descripcion">Descripción</label>
          <textarea id="descripcion" value={descripcion} onChange={(e) => setDescripcion(e.target.value)} placeholder="Escribe o dicta con el micrófono del teclado" />
        </div>

        <div className="campo">
          <span className="etiqueta">Prioridad</span>
          <div className="chips">
            {PRIORIDADES.map((p) => (
              <button key={p} type="button" className={`chip ${prioridad === p ? 'act' : ''}`} aria-pressed={prioridad === p} onClick={() => setPrioridad(p)}>
                {PRIORIDAD_TEXTO[p]}
              </button>
            ))}
          </div>
        </div>

        <div className="campo">
          <label htmlFor="subcontrata">Subcontrata responsable</label>
          {(subs.datos ?? []).length > 0 && (
            <div className="chips">
              <button type="button" className={`chip ${subcontrata === '' ? 'act' : ''}`} onClick={() => setSubcontrata('')}>
                Sin asignar
              </button>
              {(subs.datos ?? []).map((s) => (
                <button key={s.id} type="button" className={`chip ${subcontrata === s.nombre ? 'act' : ''}`} onClick={() => setSubcontrata(s.nombre)}>
                  {s.nombre}
                </button>
              ))}
            </div>
          )}
          <input id="subcontrata" type="text" list="lista-subcontratas" value={subcontrata} onChange={(e) => setSubcontrata(e.target.value)} placeholder="O escribe una nueva (se añade a la lista)" />
          <datalist id="lista-subcontratas">
            {(subs.datos ?? []).map((s) => (
              <option key={s.id} value={s.nombre} />
            ))}
          </datalist>
        </div>

        {edicion && (
          <div className="panel">
            <label className="interruptor">
              Marcar como reparado
              <input type="checkbox" checked={estado === 'reparado'} onChange={(e) => setEstado(e.target.checked ? 'reparado' : 'abierto')} />
            </label>
          </div>
        )}

        {error && <p className="error">{error}</p>}
        {error && /versión gratuita/.test(error) && <Link className="btn-texto" to="/plan">Ver la versión de pago</Link>}

        <div className="acciones">
          <button type="button" className="btn" disabled={guardando} onClick={() => nav(volver)}>
            Cancelar
          </button>
          <button type="submit" className="btn btn-primario" disabled={guardando}>
            {guardando ? 'Guardando…' : 'Guardar fallo'}
          </button>
        </div>

        {edicion && (
          <button type="button" className="btn btn-peligro" disabled={guardando} onClick={() => void eliminar()}>
            Eliminar fallo
          </button>
        )}
      </form>
      {marcando && <MarcarFoto src={marcando.src} onGuardar={fotoMarcada} onCancelar={() => setMarcando(null)} />}
    </Pantalla>
  )
}
